<?php esc_html_e('Hello #_BOOKINGNAME', 'em-pro'); ?>


<?php esc_html_e('Your waitlist reservation of #_BOOKINGSPACES spaces for #_EVENTNAME on #_EVENTDATES at #_EVENTTIMES has been cancelled.', 'em-pro'); ?>


<?php esc_html_e('Best Regards,', 'em-pro'); ?>


#_CONTACTNAME
