<?php esc_html_e('Hello #_BOOKINGNAME', 'em-pro'); ?>


<?php esc_html_e('Your wait-listed reservation for #_EVENTNAME has expired. You will need to re-apply for the waiting lists if you wish to book again.', 'em-pro'); ?>


<?php esc_html_e('Please remember that you have #_WAITLIST_EXPIRY hours to book reserved spaces once they become available, you will be notified when that happens.', 'em-pro'); ?>


<?php esc_html_e('Best Regards,', 'em-pro'); ?>


#_CONTACTNAME