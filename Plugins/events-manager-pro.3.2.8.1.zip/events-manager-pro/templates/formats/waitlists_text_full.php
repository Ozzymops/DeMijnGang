<p>
	<?php esc_html_e('This event is fully booked. You can join a waitlist and if an elegible ticket becomes available, you will be notified by email to make a booking.', 'em-pro'); ?>

</p>
<p>
	<?php esc_html_e('There are no more spaces left available on the waitlist. Please check back later, as spaces may become available.', 'em-pro'); ?>
	
</p>