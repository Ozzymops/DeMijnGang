<?php
// no valid booking found if we get here
?>
<div class="em-booking-message em-booking-message-error">
	<?php esc_html_e('Booking could not be found.', 'em-pro'); ?>
</div>
<?php
