<?php
/* @var $EM_Event EM_Event */
?>
<div class="<?php em_template_classes('event-booking-form'); ?> input">
	<div class="em-booking-message">
		<?php
		echo get_option('dbem_waitlists_text_full');
		?>
	</div>
</div>