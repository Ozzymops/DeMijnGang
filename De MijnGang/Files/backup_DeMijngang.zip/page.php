<?php
$map=array('pid_6881857'=>'/pid_6881857/','pid_6880722'=>'/Home/','pid_6881915'=>'/Nieuws/','pid_6881798'=>'/Stichting-de-Mijn-Gang/','pid_7003181'=>'/Stichting-de-Mijn-Gang/Wie-zijn-wij/','pid_7003182'=>'/Stichting-de-Mijn-Gang/Activiteiten-Agenda/','pid_7002716'=>'/Stichting-de-Mijn-Gang/Vrijwilliger-Worden/','pid_7287354'=>'/Stichting-de-Mijn-Gang/Het-Beleid/','pid_7103779'=>'/Stichting-de-Mijn-Gang/Blogs/','pid_6881799'=>'/In-ons-gebouw/','pid_7003183'=>'/In-ons-gebouw/Safe-Harbor/','pid_7003184'=>'/In-ons-gebouw/Schietvereniging-Diana-58/','pid_7003185'=>'/In-ons-gebouw/Body-Soul-Viele/','pid_7003186'=>'/In-ons-gebouw/MK-Audio/','pid_6880719'=>'/Een-stukje-geschiedenis/','pid_6880721'=>'/Achter-de-schermen/','pid_7103394'=>'/Achter-de-schermen/Hoe-is-de-MijnGang-ontstaan/','pid_7103395'=>'/Achter-de-schermen/Ons-Team/','pid_6880718'=>'/Contact/');
$key=preg_replace('/^\/([^\/]*).*/', '$1', $_SERVER["PATH_INFO"]);
if(isset($map[$key])){
  header('Location: '.$map[$key]);
}else{
  header('Location: /');
}
?>