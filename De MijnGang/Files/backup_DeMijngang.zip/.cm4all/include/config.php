<?php
$config = array(
  'accountid' => '2034742',
  'mediadb' => './.cm4all/mediadb/',
  'listingkey' => 'VVBKONQMD4AMRXXWH6WA',
  'hosting-backend-server' => 'configpanel.strato-editor.com',
  'backend-server' => 'strato-editor.com:8001',
  'viewurl' => 'http://512291334.swh.strato-hosting.eu',
  'maxiprocfilesize' => '10000000',
  'maxiprocimagesize' => '5000'
);
?>
