<?php
 
require_once(dirname(__FILE__).DIRECTORY_SEPARATOR."include/base.php");
handleBengProxyRequest();
