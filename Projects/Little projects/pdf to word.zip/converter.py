from pdf2docx import Converter
import os

directory = os.getcwd()

for file in os.listdir(directory):
    if file.endswith(".pdf"):
        file_original = os.path.join(directory, file)
        file_new = os.path.join(directory, os.path.splitext(file)[0] + ".docx")
        file_convert = Converter(file_original)
        file_convert.convert(file_new)
        file_convert.close()